let C12 = () =>{
    return (<h3>C12let component</h3>);
}



