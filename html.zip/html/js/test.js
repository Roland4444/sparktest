'use strict';

class Test extends React.Component {
    render() {
        return <h1>Hello World!</h1>;
    }
}