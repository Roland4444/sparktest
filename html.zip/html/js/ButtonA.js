
class ButtonA extends React.Component{

render(){
    return <button type="button"  class="btn btn-danger">Comp A''</button>

}
}